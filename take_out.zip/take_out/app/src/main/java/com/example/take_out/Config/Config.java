package com.example.take_out.Config;

public class Config {
    public static String baseUrl="http://115.29.246.231/basePro/";
}
